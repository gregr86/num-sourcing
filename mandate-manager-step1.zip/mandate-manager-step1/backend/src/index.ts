
import { Elysia, t } from 'elysia'
import { cookie } from '@elysiajs/cookie'
import { cors } from '@elysiajs/cors'
import { prisma } from './prisma'
import { getUserFromToken, issueAccessToken, verifyPassword, mustBe } from './auth'
import dayjs from 'dayjs'

const app = new Elysia()
  .use(cors({ origin: true, credentials: true }))
  .use(cookie())
  .get('/health', () => ({ ok: true }))

  // Auth: login
  .post('/auth/login',
    async ({ body, set, cookie }) => {
      const { email, password } = body as { email: string; password: string }
      const user = await prisma.user.findUnique({ where: { email } })
      if (!user) {
        set.status = 401
        return { error: 'Invalid credentials' }
      }
      const ok = await verifyPassword(password, user.password)
      if (!ok) {
        set.status = 401
        return { error: 'Invalid credentials' }
      }
      const token = await issueAccessToken({ id: user.id, email: user.email, role: user.role })
      cookie.set('access_token', token, { httpOnly: true, sameSite: 'lax', secure: false, path: '/' })
      return { ok: true, role: user.role, email: user.email }
    },
    {
      body: t.Object({ email: t.String(), password: t.String() })
    }
  )

  // Auth: me
  .get('/auth/me', async ({ cookie, set }) => {
    const user = await getUserFromToken(cookie.get('access_token')?.value)
    if (!user) {
      set.status = 401
      return { error: 'Unauthenticated' }
    }
    return { user }
  })

  // Reserve mandate number (AGENT)
  .post('/mandates/reserve', async ({ cookie, set }) => {
    const auth = await getUserFromToken(cookie.get('access_token')?.value)
    if (!auth) {
      set.status = 401
      return { error: 'Unauthenticated' }
    }
    // restrict to AGENT for now
    // @ts-ignore
    if (auth.role !== 'AGENT') {
      set.status = 403
      return { error: 'Forbidden' }
    }
    const next = await prisma.mandateNumber.findFirst({
      where: { status: 'AVAILABLE' },
      orderBy: { code: 'asc' }
    })
    if (!next) {
      set.status = 409
      return { error: 'No available number' }
    }
    const deadline = dayjs().add(7, 'day').toDate()
    await prisma.$transaction([
      prisma.mandateNumber.update({ where: { id: next.id }, data: { status: 'RESERVED' } }),
      prisma.mandateAllocation.create({
        data: {
          mandateNumberId: next.id,
          userId: auth.id,
          deadlineAt: deadline,
          status: 'RESERVED'
        }
      })
    ])
    return { code: next.code, deadlineAt: deadline }
  })

  // Simple admin endpoint to list board (signed this week)
  .get('/admin/board', async ({ cookie, set }) => {
    const auth = await getUserFromToken(cookie.get('access_token')?.value)
    if (!auth) {
      set.status = 401
      return { error: 'Unauthenticated' }
    }
    // @ts-ignore
    if (auth.role !== 'ADMIN') {
      set.status = 403
      return { error: 'Forbidden' }
    }
    const since = dayjs().startOf('week').toDate()
    const signed = await prisma.mandateAllocation.findMany({
      where: { status: 'SIGNED', signedAt: { gte: since } },
      include: { mandate: true, user: true }
    })
    return { signed }
  })

  .listen(3000)

console.log(`🚀 Elysia running at http://localhost:3000`)
