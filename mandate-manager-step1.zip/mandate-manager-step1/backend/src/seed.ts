
import { prisma } from './prisma'
import { hashPassword } from './auth'

async function main() {
  console.log('Seeding users...')
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@sourcinginvest.local'
  const adminPass  = process.env.ADMIN_PASSWORD || 'password'
  const agentEmail = process.env.AGENT_EMAIL || 'agent@sourcinginvest.local'
  const agentPass  = process.env.AGENT_PASSWORD || 'password'

  const [admin, agent] = await Promise.all([
    prisma.user.upsert({
      where: { email: adminEmail },
      update: {},
      create: { email: adminEmail, password: await hashPassword(adminPass), role: 'ADMIN' }
    }),
    prisma.user.upsert({
      where: { email: agentEmail },
      update: {},
      create: { email: agentEmail, password: await hashPassword(agentPass), role: 'AGENT' }
    })
  ])
  console.log('Admin:', admin.email, 'Agent:', agent.email)

  console.log('Seeding mandate numbers...')
  // Create a batch of numbers 2025-0001..2025-0050
  const items = Array.from({ length: 50 }, (_, i) => ({
    code: `2025-${String(i + 1).padStart(4, '0')}`
  }))
  for (const it of items) {
    await prisma.mandateNumber.upsert({
      where: { code: it.code },
      update: {},
      create: { code: it.code, status: 'AVAILABLE' }
    })
  }
  console.log('Done.')
}

main().then(() => process.exit(0)).catch((e) => {
  console.error(e)
  process.exit(1)
})
